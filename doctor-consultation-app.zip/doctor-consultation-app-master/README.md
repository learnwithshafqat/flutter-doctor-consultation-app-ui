![](https://github.com/rifqieh/doctor-consultation-app/blob/master/doctor_consultation.png)

# Doctor Consultation App
## [Youtube: Doctor Consultation App - Speed Code](https://www.youtube.com/watch?v=stNC-6nIskU&feature=youtu.be)
Packages
- [google_fonts](https://pub.dev/packages/google_fonts)
- [flutter_svg](https://pub.dev/packages/flutter_svg)

Design Credit: [Asif Robhan](https://dribbble.com/shots/9780713-Doctor-Consultation-App)
